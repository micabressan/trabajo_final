#include <acknex.h>

int a = 10;
int b = 20;
int c;

c = a + b;

ent_create("foo.mdl", vector(100, 0, 0), NULL);

function main()
{
}