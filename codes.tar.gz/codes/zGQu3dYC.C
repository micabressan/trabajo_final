Threads usage example

Program showing the operation and use of POSIX.1 Threads

You can download this code from: http://kializer.com/5NiD   (Please copy this link and paste it on the address bar of your browser)